/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Objects;

import java.awt.image.BufferedImage;
import java.util.Random;

/**
 *
 * @author user
 */
public class watermelon extends GameObject {
    
     Random rand = new Random();
    public watermelon(){
        this.type = IGameObject.Type.NORMAL_FRUIT;
        setPositionY(0);
        setDeltay(100);
        setPositionX((int)(Math.random() * (900 + 1)));//assuming the width of the window is 900
        setDeltax(10);
        setMaxHeight((int)(Math.random() * ((900 - 500) + 1)) + 500);//assuming height of window is 900
    }


    public BufferedImage[] getImages(){
        return super.getImages("bati");
    }
    
    
    
    
}
