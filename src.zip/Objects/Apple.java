
package Objects;

import java.awt.image.BufferedImage;
import java.util.Random;

/**
 *
 * @author Rania
 */
public class Apple extends GameObject {
    Random rand = new Random();
    public Apple(){
        this.type = Type.NORMAL_FRUIT;
        setPositionY(0);
        setDeltay(100);
        setPositionX((int)(Math.random() * (900 + 1)));//assuming the width of the window is 900
        setDeltax(10);
        setMaxHeight((int)(Math.random() * ((900 - 500) + 1)) + 500);//assuming height of window is 900
    }


    public BufferedImage[] getImages(){
        return super.getImages("Apple");
    }
    
}
