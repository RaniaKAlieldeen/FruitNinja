/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Objects.GameObject;

/**
 *
 * @author Rania
 */
public interface IGameActions {

    public GameObject createGameObject();

    public void updateObjectsLocations();

    public void sliceObjects();

    public void ResetGame();

}
